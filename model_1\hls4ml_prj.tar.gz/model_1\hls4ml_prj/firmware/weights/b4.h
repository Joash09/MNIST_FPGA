//Numpy array shape [10]
//Min -0.393770247698
//Max -0.069684103131
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[10];
#else
model_default_t b4[10] = {-0.0876560062, -0.3398807943, -0.3937702477, -0.3084472418, -0.2493187934, -0.0696841031, -0.2639884055, -0.1525407284, -0.3556067050, -0.1606097072};
#endif

#endif
