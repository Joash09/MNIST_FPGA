//Numpy array shape [10]
//Min -0.342928200960
//Max -0.119360111654
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[10];
#else
model_default_t b4[10] = {-0.2319900244, -0.2739185393, -0.1917481571, -0.2921835184, -0.1855362356, -0.1606299579, -0.3235211074, -0.1703825891, -0.3429282010, -0.1193601117};
#endif

#endif
