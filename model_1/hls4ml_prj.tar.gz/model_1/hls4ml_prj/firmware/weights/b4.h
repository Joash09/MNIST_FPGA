//Numpy array shape [10]
//Min -0.464018493891
//Max -0.146091893315
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[10];
#else
model_default_t b4[10] = {-0.3515386283, -0.2413760275, -0.2208583504, -0.3841172457, -0.3170908689, -0.1678039432, -0.2362015545, -0.1460918933, -0.2269639522, -0.4640184939};
#endif

#endif
