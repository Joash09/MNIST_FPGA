//Numpy array shape [10]
//Min -0.415641754866
//Max -0.068067796528
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[10];
#else
model_default_t b4[10] = {-0.3675408959, -0.3350665867, -0.2707658708, -0.3744850457, -0.3378625214, -0.0680677965, -0.4156417549, -0.1685325950, -0.3485341370, -0.2502295673};
#endif

#endif
