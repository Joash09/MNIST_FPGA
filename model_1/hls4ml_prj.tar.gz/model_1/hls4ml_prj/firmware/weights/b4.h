//Numpy array shape [10]
//Min -0.386383533478
//Max -0.120750606060
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[10];
#else
model_default_t b4[10] = {-0.2166213542, -0.2474635839, -0.2286099792, -0.1207506061, -0.3371858299, -0.2583540082, -0.3255508542, -0.1905286014, -0.2242386490, -0.3863835335};
#endif

#endif
